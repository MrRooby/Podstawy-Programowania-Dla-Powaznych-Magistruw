
#include "ControllerPID.h"
#include <fstream>

ControllerPID::ControllerPID(double P, double I, double D){
  prev_error = 0.0;
  mem_integral = 0.0;
  setK(P);
  setTI(I);
  setTD(D);
}

void ControllerPID::nonZeroSetter(const double value, double &value_to_set){
  if(value < 0) value_to_set = 0.0;
  else value_to_set = value;
}

void ControllerPID::setK(const double value){
  nonZeroSetter(value, k);
}

void ControllerPID::setTI(const double value){
  nonZeroSetter(value, TI);
}

void ControllerPID::setTD(const double value){
  nonZeroSetter(value, TD);
}

double ControllerPID::simulateP(const double error){
  return k * error;
}

double ControllerPID::simulateI(const double error){
  if(TI <= 0.0) return 0.0;
  mem_integral += error;
  return mem_integral / TI;
}

double ControllerPID::simulateD(const double error){
  if(TD <= 0.0) {
    prev_error = error;
    return 0.0;
  }
  double d_part = TD * (error - prev_error);
  prev_error = error;
  return d_part;
}

double ControllerPID::simulate(const double error){
  double p_part = simulateP(error);
  double i_part = simulateI(error);
  double d_part = simulateD(error);
  return p_part + i_part + d_part;
}

void ControllerPID::serialize(const std::string& filename){
  using namespace nlohmann;
  try {
    std::string ext = ".json";
    if (filename.length() < ext.length() || 
        filename.compare(filename.length() - ext.length(), ext.length(), ext) != 0) {
      throw std::invalid_argument("Error: File extension must be .json");
    }

    std::ofstream file(filename);
    if (!file.is_open()) {
      throw std::runtime_error("Error: File does not exist or cannot be opened: " + filename);
    }

    json j;
    j["k"] = k;
    j["TI"] = TI;
    j["TD"] = TD;
    j["mem_integral"] = mem_integral;
    j["prev_error"] = prev_error;
    
    file << j.dump(2) << std::endl;
    file.close();
  }
  catch (const std::exception& e) {
    throw e;
  }
}

void ControllerPID::deserialize(const std::string& filename){
  using namespace nlohmann;
  try {
    std::string ext = ".json";
    if (filename.length() < ext.length() || 
        filename.compare(filename.length() - ext.length(), ext.length(), ext) != 0) {
      throw std::invalid_argument("Error: File extension must be .json");
    }

    std::ifstream file(filename);
    if (!file.is_open()) {
      throw std::runtime_error("Error: File does not exist or cannot be opened: " + filename);
    }

    json j;
    file >> j;
    file.close();

    k = j["k"];
    TI = j["TI"];
    TD = j["TD"];
    mem_integral = j["mem_integral"];
    prev_error = j["prev_error"];
  }
  catch (const std::exception& e) {
    throw e;
  }
}
