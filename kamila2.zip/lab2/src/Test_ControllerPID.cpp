#include "Test_ControllerPID.h"

void Test_ControllerPID::performTests() {
  test_RegulatorP_noExcitation();
  test_RegulatorP_unitStep();
  test_RegulatorPI_unitStep_v1();
  test_RegulatorPI_unitStep_v2();
  test_RegulatorPID_unitStep();
  test_Serialization();
}

void Test_ControllerPID::test_RegulatorP_noExcitation() {
  std::cerr << "RegP (k = 0.5) -> zero excitation test: ";
  try {
    ControllerPID instance(0.5);
    constexpr size_t ITER = 30;
    std::vector<double> input(ITER);
    std::vector<double> expected(ITER);
    std::vector<double> actual(ITER);

    for (int i = 0; i < ITER; i++)
      actual[i] = instance.simulate(input[i]);

    if (compareSequences(expected, actual))
      std::cerr << "OK!\n";
    else {
      std::cerr << "FAIL!\n";
      reportErrorInSequence(expected, actual);
    }
  }
  catch (...) {
    std::cerr << "INTERRUPTED! (unexpected exception)\n";
  }
}

void Test_ControllerPID::test_RegulatorP_unitStep() {
  std::cerr << "RegP (k = 0.5) -> unit step test: ";
  try {
    ControllerPID instance(0.5);
    constexpr size_t ITER = 30;
    std::vector<double> input(ITER);
    std::vector<double> expected(ITER);
    std::vector<double> actual(ITER);

    for (int i = 0; i < ITER; i++)
      input[i] = !!i;
    expected = { 0.0, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5 };

    for (int i = 0; i < ITER; i++)
      actual[i] = instance.simulate(input[i]);

    if (compareSequences(expected, actual))
      std::cerr << "OK!\n";
    else {
      std::cerr << "FAIL!\n";
      reportErrorInSequence(expected, actual);
    }
  }
  catch (...) {
    std::cerr << "INTERRUPTED! (unexpected exception)\n";
  }
}

void Test_ControllerPID::test_RegulatorPI_unitStep_v1() {
  std::cerr << "RegPI (k = 0.5, TI = 1.0) -> unit step test v1: ";
  try {
    ControllerPID instance(0.5, 1.0);
    constexpr size_t ITER = 30;
    std::vector<double> input(ITER);
    std::vector<double> expected(ITER);
    std::vector<double> actual(ITER);

    for (int i = 0; i < ITER; i++)
      input[i] = !!i;
    expected = { 0, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 10.5, 11.5, 12.5, 13.5, 14.5, 15.5, 16.5, 17.5, 18.5, 19.5, 20.5, 21.5, 22.5, 23.5, 24.5, 25.5, 26.5, 27.5, 28.5, 29.5 };

    for (int i = 0; i < ITER; i++)
      actual[i] = instance.simulate(input[i]);

    if (compareSequences(expected, actual))
      std::cerr << "OK!\n";
    else {
      std::cerr << "FAIL!\n";
      reportErrorInSequence(expected, actual);
    }
  }
  catch (...) {
    std::cerr << "INTERRUPTED! (unexpected exception)\n";
  }
}

void Test_ControllerPID::test_RegulatorPI_unitStep_v2() {
  std::cerr << "RegPI (k = 0.5, TI = 10.0) -> unit step test v2: ";
  try {
    ControllerPID instance(0.5, 10.0);
    constexpr size_t ITER = 30;
    std::vector<double> input(ITER);
    std::vector<double> expected(ITER);
    std::vector<double> actual(ITER);

    for (int i = 0; i < ITER; i++)
      input[i] = !!i;
    expected = { 0, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3, 3.1, 3.2, 3.3, 3.4 };

    for (int i = 0; i < ITER; i++)
      actual[i] = instance.simulate(input[i]);

    if (compareSequences(expected, actual))
      std::cerr << "OK!\n";
    else {
      std::cerr << "FAIL!\n";
      reportErrorInSequence(expected, actual);
    }
  }
  catch (...) {
    std::cerr << "INTERRUPTED! (unexpected exception)\n";
  }
}

void Test_ControllerPID::test_RegulatorPID_unitStep() {
  std::cerr << "RegPID (k = 0.5, TI = 10.0, TD = 0.2) -> unit step test: ";
  try {
    ControllerPID instance(0.5, 10.0, 0.2);
    constexpr size_t ITER = 30;
    std::vector<double> input(ITER);
    std::vector<double> expected(ITER);
    std::vector<double> actual(ITER);

    for (int i = 0; i < ITER; i++)
      input[i] = !!i;
    expected = { 0, 0.8, 0.7, 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3, 3.1, 3.2, 3.3, 3.4 };

    for (int i = 0; i < ITER; i++)
      actual[i] = instance.simulate(input[i]);

    if (compareSequences(expected, actual))
      std::cerr << "OK!\n";
    else {
      std::cerr << "FAIL!\n";
      reportErrorInSequence(expected, actual);
    }
  }
  catch (...) {
    std::cerr << "INTERRUPTED! (unexpected exception)\n";
  }
}

void Test_ControllerPID::test_Serialization() {
  std::cerr << "Serialization/Deserialization test: ";
  try {
    ControllerPID controller1(0.5, 1.0, 0.2);
    controller1.simulate(1.0);
    controller1.serialize("controller_test.json");

    ControllerPID controller2(0.0);
    controller2.deserialize("controller_test.json");

    constexpr size_t ITER = 10;
    std::vector<double> input(ITER);
    std::vector<double> output1(ITER);
    std::vector<double> output2(ITER);

    for (int i = 0; i < ITER; i++)
      input[i] = !!i;

    ControllerPID controller3(0.5, 1.0, 0.2);
    controller3.simulate(1.0);
    
    for (int i = 0; i < ITER; i++) {
      output1[i] = controller3.simulate(input[i]);
      output2[i] = controller2.simulate(input[i]);
    }

    if (compareSequences(output1, output2))
      std::cerr << "OK!\n";
    else {
      std::cerr << "FAIL!\n";
      reportErrorInSequence(output1, output2);
    }
  }
  catch (...) {
    std::cerr << "INTERRUPTED! (unexpected exception)\n";
  }
}
