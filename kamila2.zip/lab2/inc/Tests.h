#pragma once
#include <vector>
#include <iostream>
#include <iomanip>
#include <cmath>

class Tests {
public:
  virtual ~Tests() = default;

  static void reportErrorInSequence(std::vector<double>& expected, std::vector<double>& actual) {
    constexpr size_t PREC = 3;
    std::cerr << std::fixed << std::setprecision(PREC);
    std::cerr << "  Expected:\t";
    for (auto& el : expected)
      std::cerr << el << ", ";
    std::cerr << "\n  Actual:\t";
    for (auto& el : actual)
      std::cerr << el << ", ";
    std::cerr << std::endl << std::endl;
  }

  static bool compareSequences(std::vector<double>& expected, std::vector<double>& actual) {
    constexpr double TOL = 1e-3;
    bool result = actual.size() == expected.size();
    for (int i = 0; result && i < actual.size(); i++)
      result = fabs(actual[i] - expected[i]) < TOL;
    return result;
  }
};
