#pragma once
#include <vector>
#include <iostream>
#include <iomanip>
#include <cmath>

#include "ControllerPID.h"
#include "Tests.h"

class Test_ControllerPID : public Tests {
public:
  ~Test_ControllerPID() = default;
  static void performTests();

private:
  static void test_RegulatorP_noExcitation();
  static void test_RegulatorP_unitStep();
  static void test_RegulatorPI_unitStep_v1();
  static void test_RegulatorPI_unitStep_v2();
  static void test_RegulatorPID_unitStep();
  static void test_Serialization();
};
