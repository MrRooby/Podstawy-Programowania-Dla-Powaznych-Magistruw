#pragma once
#include "ObjectSISO.h"
#include <string>
#include <nlohmann/json.hpp>

class ControllerPID : public ObjectSISO {
private:
  double k = 0.0;
  double TI = 0.0;
  double TD = 0.0;
  double mem_integral = 0.0;
  double prev_error = 0.0;
  
  void nonZeroSetter(const double value, double &value_to_set);
  double simulateP(const double error);
  double simulateI(const double error);
  double simulateD(const double error);
  
public:
  ControllerPID(double P = 0.0, double I = 0.0, double D = 0.0);

  void setK(const double value);
  void setTI(const double value);
  void setTD(const double value);

  double simulate(const double error) override;
  
  void serialize(const std::string& filename);
  void deserialize(const std::string& filename);
};
