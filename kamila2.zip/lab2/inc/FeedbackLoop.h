#pragma once
#include "ControllerPID.h"
#include "ModelArx.h"

double simulateFeedbackLoop(ControllerPID& controller, ModelArx& model, const double setpoint) {
  static double prev_output = 0.0;
  double error = setpoint - prev_output;
  double control = controller.simulate(error);
  double output = model.simulate(control);
  prev_output = output;
  return output;
}
